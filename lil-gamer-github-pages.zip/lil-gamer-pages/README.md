# Little gamer

Fan-made site for [Little gamer](https://www.youtube.com/@not_little_gamer) (`@Not_Little_gamer`).

Trying to make people's days better.

**Not officially affiliated.**

## Deploy (GitHub Pages)

1. Create a new repo on GitHub (example name: `lil-gamer`).
2. Run the commands below in this folder (replace `YOUR_USERNAME` and `REPO_NAME`):

```bash
git init
git add .
git commit -m "Little gamer fan site"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/REPO_NAME.git
git push -u origin main
```

3. On GitHub: **Settings → Pages**
4. Source: **Deploy from a branch**
5. Branch: **main** · Folder: **/ (root)** → **Save**

Site URL will be: `https://YOUR_USERNAME.github.io/REPO_NAME/`

For a user/org site at `https://YOUR_USERNAME.github.io/`, name the repo `YOUR_USERNAME.github.io` instead.
